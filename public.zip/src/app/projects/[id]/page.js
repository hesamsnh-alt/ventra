"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import ProjectBOQ from "./ProjectBOQ";
import ProjectEstimate from "./ProjectEstimate";
import ProjectQuotation from "./ProjectQuotation";
import ProjectDrawingCenter from "./ProjectDrawingCenter";
import {
  ArrowLeft,
  CalendarDays,
  CircleUserRound,
  ClipboardList,
  FileText,
  TriangleAlert,
} from "lucide-react";

import { getProjectById } from "@/data/projects";

import ProjectTimeline from "./ProjectTimeline";
import ProjectTasks from "./ProjectTasks";
import ProjectDailyReports from "./ProjectDailyReports";
import ProjectActivity from "./ProjectActivity";
import ProjectDocuments from "./ProjectDocuments";

import "./ProjectWorkspace.css";

export default function ProjectWorkspace() {
  const params = useParams();

  const [project, setProject] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const selectedProject = getProjectById(params.id);

    setProject(selectedProject || null);
    setLoading(false);
  }, [params.id]);

  if (loading) {
    return (
      <main className="project-workspace">
        <div className="project-loading">
          Loading project...
        </div>
      </main>
    );
  }

  if (!project) {
    return (
      <main className="project-workspace">
        <div className="project-not-found">
          <h1>Project not found</h1>

          <p>
            This project does not exist or has been removed.
          </p>

          <Link href="/dashboard">
            Return to Dashboard
          </Link>
        </div>
      </main>
    );
  }

  return (
    <main className="project-workspace">
      <header className="project-header">
        <div>
          <Link href="/dashboard" className="project-back">
            <ArrowLeft size={17} />
            Dashboard
          </Link>

          <span className="project-code">
            PROJECT #{project.id}
          </span>

          <h1>{project.name}</h1>

          <p>
            {project.client} · {project.location}
          </p>
        </div>

        <div className="project-health">
          <span>Project Health</span>
          <strong>{project.health}%</strong>
        </div>
      </header>

      <nav className="project-tabs">
        <button
          type="button"
          className="project-tab project-tab-active"
        >
          Overview
        </button>

        <button type="button" className="project-tab">
          Schedule
        </button>

        <button type="button" className="project-tab">
          Drawings
        </button>

        <button type="button" className="project-tab">
          BOQ
        </button>

        <button type="button" className="project-tab">
          Estimate
        </button>

        <button type="button" className="project-tab">
          Daily Reports
        </button>

        <button type="button" className="project-tab">
          Documents
        </button>
      </nav>

      <section className="project-summary-grid">
        <article className="project-summary-card">
          <CalendarDays size={21} />

          <span>Deadline</span>

          <strong>
            {project.deadline || "Not set"}
          </strong>
        </article>

        <article className="project-summary-card">
          <ClipboardList size={21} />

          <span>Overall Progress</span>

          <strong>{project.progress}%</strong>
        </article>

        <article className="project-summary-card">
          <FileText size={21} />

          <span>Pending Reports</span>

          <strong>{project.pendingReports}</strong>
        </article>

        <article className="project-summary-card project-summary-warning">
          <TriangleAlert size={21} />

          <span>Open Issues</span>

          <strong>{project.openIssues}</strong>
        </article>
      </section>

      <section className="project-content-stack">
        <ProjectTimeline />
        <ProjectTasks />
        <ProjectDailyReports />
        <ProjectActivity />
        <ProjectDocuments />
        <ProjectBOQ />
        <ProjectEstimate />
        <ProjectQuotation />
        <ProjectDrawingCenter />
      </section>

      <section className="project-side-grid">
        <article className="project-panel">
          <div className="project-panel-heading">
            <div>
              <span>PROJECT TEAM</span>
              <h2>Assigned Users</h2>
            </div>
          </div>

          <div className="project-user">
            <CircleUserRound size={32} />

            <div>
              <strong>{project.manager}</strong>
              <span>Project Manager</span>
            </div>
          </div>

          <div className="project-user">
            <CircleUserRound size={32} />

            <div>
              <strong>{project.supervisor}</strong>
              <span>Site Supervisor</span>
            </div>
          </div>
        </article>

        <article className="project-panel">
          <div className="project-panel-heading">
            <div>
              <span>TODAY</span>
              <h2>Daily Update</h2>
            </div>
          </div>

          <ul className="daily-update-list">
            <li>Project created successfully</li>
            <li>Project team assigned</li>
            <li>Schedule waiting to be configured</li>
            <li>No daily report submitted yet</li>
          </ul>

          <button
            type="button"
            className="daily-report-button"
          >
            Add Daily Report
          </button>
        </article>
      </section>
    </main>
  );
}